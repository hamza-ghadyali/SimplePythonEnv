# old version
# import bz2
# import sys

# opener = bz2.open

# if __name__ == "__main__":
#     f = bz2.open(sys.argv[1], mode="wt")
#     f.write(" ".join(sys.argv[2:]))
#     f.close()

# new version after creating util module with writer.py
import bz2

from demo_reader.util import writer

opener = bz2.open

if __name__ == "__main__":
    writer.main(opener)