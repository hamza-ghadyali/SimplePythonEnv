#print("printing multi-reader-program/__main__.py")


import sys

from demo_reader.multireader import MultiReader

filename = sys.argv[1]
r = MultiReader(filename)
print(r.read())
r.close()

# run this as an executable program from the dir containing multi-reader-program
# $python multi-reader-program test.bz2

